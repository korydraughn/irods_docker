#ifndef IRODS_VERSION_H__
#define IRODS_VERSION_H__

#define IRODS_VERSION_MAJOR             4
#define IRODS_VERSION_MINOR             2
#define IRODS_VERSION_PATCHLEVEL        5

#define IRODS_VERSION_INTEGER           (4*1000000 + 2*1000 + 5)

#endif  // IRODS_VERSION_H__

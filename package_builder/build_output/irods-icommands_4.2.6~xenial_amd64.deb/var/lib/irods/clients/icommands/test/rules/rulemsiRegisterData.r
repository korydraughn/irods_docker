acRegisterData { msiRegisterData ::: misRollback; }

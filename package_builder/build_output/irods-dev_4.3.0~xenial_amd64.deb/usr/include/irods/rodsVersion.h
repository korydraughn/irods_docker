/*** Copyright (c), The Regents of the University of California            ***
 *** For more information please refer to files in the COPYRIGHT directory ***/

/* defines the release version and API version
 */

#include "irods_version.h"

#ifndef RODS_VERSION_H
#define RODS_VERSION_H

#define RODS_REL_VERSION        "rods4.3.0"
#define RODS_API_VERSION        "d"

#endif	/* RODS_VERSION_H */
